package com.example.rekrutmen_bts

class AuthRepository {
//    fun getRegister(registerEntity: RegisterEntity): MutableLiveData<ApiResponse<UserResponse>> {
//        val json = JSONObject()
//        val mutableLiveData = MutableLiveData<ApiResponse<UserResponse>>()
//        mutableLiveData.value = ApiResponse.Loading
//        json.put("email", registerEntity.email)
//        json.put("username", registerEntity.username)
//        json.put("password", registerEntity.password)
//
//        val requestBody = json.toString().toRequestBody("application/json".toMediaTypeOrNull())
//        Log.d("TEST1",json.toString())
//        val responseBodyCallApi = ApiClient().getApi().register(requestBody)
//        responseBodyCallApi.enqueue(object  : Callback<UserResponse>{
//            override fun onResponse(call: Call<UserResponse>, response: Response<UserResponse>) {
//                if(response.isSuccessful){
//                    val data = response.body()
//                    if(data != null){
//                        if (data.error != null) mutableLiveData.value = ApiResponse.Error(data.error.toString())
//                        else mutableLiveData.value = ApiResponse.Success(data)
//                    } else mutableLiveData.value = ApiResponse.Error("Failed get user")
//                } else mutableLiveData.value = ApiResponse.Error("Email already used")
//            }
//
//            override fun onFailure(call: Call<UserResponse>, t: Throwable) {
//                mutableLiveData.value = ApiResponse.Error(t.message.toString())
//            }
//
//        })
//        return mutableLiveData
//    }
//
//
//    fun getLogin(loginEntity: LoginEntity): MutableLiveData<ApiResponse<UserResponse>> {
//        val json = JSONObject()
//        json.put("username", loginEntity.username)
//        json.put("password", loginEntity.password)
//        val mutableLiveData = MutableLiveData<ApiResponse<UserResponse>>()
//        mutableLiveData.value = ApiResponse.Loading
//
//        val requestBody = json.toString().toRequestBody("application/json".toMediaTypeOrNull())
//        val responseBodyCallApi = ApiClient().getApi().login(requestBody)
//        responseBodyCallApi.enqueue(object  : Callback<UserResponse>{
//            override fun onResponse(call: Call<UserResponse>, response: Response<UserResponse>) {
//                Log.d("TEST",response.body().toString())
//                val data = response.body()
//                if(data != null){
//                    if (data.error != null) mutableLiveData.value = ApiResponse.Error("Email / Password Salah, Silahkan Masukan Kembali!")
//                    else mutableLiveData.value = ApiResponse.Success(data)
//                } else mutableLiveData.value = ApiResponse.Error("Email / Password Salah, Silahkan Masukan Kembali!")
//            }
//
//            override fun onFailure(call: Call<UserResponse>, t: Throwable) {
//                mutableLiveData.value = ApiResponse.Error(t.message.toString())
//            }
//
//        })
//        return mutableLiveData
//    }
}