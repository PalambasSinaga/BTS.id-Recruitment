package com.example.rekrutmen_bts

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.recyclerview_item.view.*

class MainAdapter(
    private val item: MutableList<Item>
): RecyclerView.Adapter<MainAdapter.ItemViewHolder>(){

    class ItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        return ItemViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.recyclerview_item,
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val curItem = item[position]
        holder.itemView.apply {
            tvItemTitle.text = curItem.title
            cbCheckbox.isChecked = curItem.isChecked
        }
    }

    override fun getItemCount(): Int {
        return item.size
    }
}