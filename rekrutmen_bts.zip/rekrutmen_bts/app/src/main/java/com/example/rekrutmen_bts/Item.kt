package com.example.rekrutmen_bts

data class Item(
    val title: String,
    val isChecked: Boolean = false
)
