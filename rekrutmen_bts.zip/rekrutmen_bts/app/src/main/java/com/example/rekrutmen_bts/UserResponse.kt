package com.example.rekrutmen_bts

import com.google.gson.annotations.SerializedName

data class UserResponse(
    @SerializedName("user") val user : UserEntity? = null,
    @SerializedName("token") val token : String? = null,
    @SerializedName("error") val error : String? = null
)