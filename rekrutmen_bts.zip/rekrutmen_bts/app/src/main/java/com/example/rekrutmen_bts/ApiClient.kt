package com.example.rekrutmen_bts

//import com.example.rekrutmen_bts.BuildConfig
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class ApiClient {

    fun getApi(): ApiService {
        val retrofit = Retrofit.Builder()
//            .baseUrl(BuildConfig.BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        return retrofit.create(ApiService::class.java)
    }
}