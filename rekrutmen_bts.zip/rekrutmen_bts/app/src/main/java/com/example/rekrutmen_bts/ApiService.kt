package com.example.rekrutmen_bts

import okhttp3.RequestBody
import retrofit2.http.Body
import retrofit2.http.POST

interface ApiService {
    @POST("login")
    fun login(
        @Body requestBody: RequestBody
    )

    @POST("register")
    fun register(
        @Body requestBody: RequestBody
    )
}